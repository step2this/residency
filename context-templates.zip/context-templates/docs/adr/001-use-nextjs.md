# ADR 001: Use Next.js 15 with App Router for Frontend

**Status**: Accepted  
**Date**: 2024-12-08  
**Deciders**: [Your Name], Claude (AI Assistant)  
**Technical Story**: Project setup, framework selection

---

## Context

We're building a mobile-first web application for divorced parents to coordinate custody schedules. The application needs to:

- Work seamlessly on mobile devices (primary use case)
- Provide excellent SEO for marketing/landing pages
- Support both authenticated (app) and public (marketing) pages
- Enable rapid development with a small team
- Handle real-time updates (notifications, schedule changes)
- Be cost-effective to deploy and scale

Current constraints:
- Solo developer initially, need high productivity
- Limited DevOps resources (prefer managed services)
- Need to launch MVP in 3 months
- Mobile bandwidth matters (users may have limited data)

We have experience with React and TypeScript but are open to the best solution for our needs.

---

## Decision

We will use **Next.js 15 with the App Router** (React Server Components) as our frontend framework.

Stack specifics:
- Next.js 15 (latest stable)
- React 19
- TypeScript (strict mode)
- Tailwind CSS for styling
- Deploy to Vercel (initially) or AWS Amplify

---

## Rationale

### Option 1: Create React App (CRA) / Vite + React
**Pros**:
- Simple setup, fewer concepts to learn
- Maximum flexibility in architecture
- Well understood by most React developers

**Cons**:
- No built-in SSR/SSG (bad for SEO)
- Client-side routing only (slower initial loads)
- No file-based routing (more boilerplate)
- Need to set up build optimization ourselves
- Deprecated (CRA) or less production-ready (Vite SPA)

### Option 2: Remix
**Pros**:
- Excellent performance model (progressive enhancement)
- Great developer experience
- Strong focus on web standards
- Built-in form handling and mutations

**Cons**:
- Less mature ecosystem than Next.js
- Fewer deployment options
- Steeper learning curve for React developers
- Less community content and support

### Option 3: SvelteKit / Solid Start
**Pros**:
- Excellent performance
- Less JavaScript shipped to client
- Modern developer experience

**Cons**:
- Smaller ecosystem and community
- Less familiarity (learning curve)
- Fewer libraries and integrations
- Harder to hire developers if needed

### Selected Option: Next.js 15 with App Router

**Why we chose this**:

1. **Server Components reduce client JavaScript**: Perfect for mobile users with limited bandwidth. We can render most UI on the server and only ship interactive components.

2. **File-based routing**: Matches our mental model for pages (`/app/schedule/page.tsx` → `/schedule` route). Reduces boilerplate.

3. **Built-in optimization**: Image optimization, font optimization, code splitting all automatic.

4. **Excellent deployment story**: Vercel makes deployment trivial. Can also deploy to AWS, Netlify, or self-host.

5. **Large ecosystem**: Huge community, lots of libraries, extensive documentation, AI tools understand it well.

6. **API routes**: Can prototype backend endpoints quickly before moving to Lambda.

7. **TypeScript-first**: Excellent TypeScript support out of the box.

8. **Familiar to React developers**: Easier to onboard help if needed.

9. **ISR and caching**: Can serve personalized content fast with smart caching strategies.

**Trade-offs accepted**:

1. **Vendor preference to Vercel**: While we can deploy elsewhere, some features work best on Vercel. Mitigation: Design to be portable from day one.

2. **Complexity of App Router**: More concepts to learn (Server Components, Client Components, loading.tsx, error.tsx). Mitigation: Start simple, adopt features as needed.

3. **Not the lightest framework**: Svelte/Solid might ship less JS, but Next.js is "light enough" for our needs and offers better DX trade-offs.

---

## Consequences

### Positive Consequences

- **Fast initial loads**: Server-side rendering means users see content immediately, critical for mobile experience.

- **SEO-friendly**: Marketing pages, landing pages, and public-facing content will rank well.

- **Developer productivity**: File-based routing, hot reload, TypeScript integration make development fast.

- **Future-proofing**: Server Components are the future of React. We're betting on the mainstream direction.

- **Easy deployment**: Vercel provides zero-config deployment, preview URLs, and rollbacks.

- **Performance by default**: Next.js optimizes images, fonts, and code splitting automatically.

### Negative Consequences

- **Learning curve for App Router**: Server vs. Client Components is a new mental model. We'll need to be intentional about where data fetching happens.  
  *Mitigation*: Start with Server Components by default, only add 'use client' when needed.

- **Build complexity**: Next.js builds can be slower than simple SPAs.  
  *Mitigation*: Use local dev mode (fast refresh), optimize build process as needed.

- **Potential over-reliance on framework magic**: May abstract away too much.  
  *Mitigation*: Understand what Next.js is doing under the hood, especially for caching and rendering.

### Neutral Consequences

- **React ecosystem**: We're committed to the React ecosystem and its evolution.

- **Node.js runtime**: We'll need Node.js for build and potentially for edge runtime.

---

## Implementation Notes

### Setup Steps

1. Initialize Next.js project:
   ```bash
   npx create-next-app@latest custody-scheduler --typescript --tailwind --app
   ```

2. Configure strict TypeScript in `tsconfig.json`

3. Set up project structure:
   ```
   /src
     /app          # App Router pages
     /components   # React components
     /lib          # Business logic
     /hooks        # Custom hooks
   ```

4. Add development dependencies:
   - ESLint, Prettier
   - Testing Library
   - Zod for validation

5. Configure deployment to Vercel

**Timeline**: Project setup completed December 2024

**Dependencies**: 
- AWS account for backend (Lambda, DynamoDB)
- GitHub repo created
- Vercel account for deployment

**Migration Path**: N/A (greenfield project)

---

## Validation

How will we know this was the right decision?

Success criteria:
- [x] Initial page load < 2 seconds on 4G
- [x] Lighthouse score > 90 for performance
- [ ] Can deploy new features in < 1 day (most cases)
- [ ] Mobile users report responsive, fast experience
- [ ] Developer velocity remains high 3 months in

**Review Date**: March 2025 (after MVP launch)

**Metrics to track**:
- Page load times (Core Web Vitals)
- Build times
- Developer time to implement features
- Bug rate related to rendering issues
- User satisfaction with performance

---

## Related Decisions

- Influences: ADR-002 (API Design)
- Influences: ADR-003 (State Management)
- Related to: ADR-005 (Deployment Strategy)

---

## References

- [Next.js Documentation](https://nextjs.org/docs)
- [React Server Components RFC](https://github.com/reactjs/rfcs/blob/main/text/0188-server-components.md)
- [Next.js App Router Best Practices](https://nextjs.org/docs/app/building-your-application)
- [Why We Chose Next.js for Our SaaS (blog examples)](https://example.com)

---

## Notes

**Additional context**:
- Evaluated in December 2024, Next.js 15 was the latest stable version
- App Router is now the recommended approach (Pages Router in maintenance)
- React 19 introduced alongside Next.js 15 with improved Server Components

**Lessons learned** (to be updated):
- [Space for future learnings as we use the framework]

**Future considerations**:
- If build times become problematic, consider Turbopack (built into Next.js 15)
- Monitor Server Component adoption in ecosystem
- Evaluate RSC performance vs. expectations
- Consider if we need ISR (Incremental Static Regeneration) for any pages
