# ADR Template

Copy this template when creating a new Architecture Decision Record.

Filename format: `NNN-short-title.md` (e.g., `001-use-nextjs.md`)

---

# ADR [NUMBER]: [Title of Decision]

**Status**: [Proposed | Accepted | Deprecated | Superseded by ADR-XXX]  
**Date**: [YYYY-MM-DD]  
**Deciders**: [List people involved in the decision]  
**Technical Story**: [GitHub Issue #XX or description]

---

## Context

What is the issue we're addressing? What forces are at play that led us to consider this decision?

Include:
- Background on the problem
- Current state
- Why a decision is needed now
- Any constraints (budget, time, technical)

Example:
"We need to choose a frontend framework for our web application. The app must be mobile-first, SEO-friendly for marketing pages, and support rapid development. We have experience with React but are open to alternatives. Performance on mobile networks is critical."

---

## Decision

What is the change that we're proposing and/or doing?

Be specific and actionable. State the decision clearly.

Example:
"We will use Next.js 15 with the App Router for our frontend application."

---

## Rationale

Why did we make this decision? What alternatives did we consider?

### Option 1: [First Alternative]
**Pros**:
- Advantage 1
- Advantage 2

**Cons**:
- Disadvantage 1
- Disadvantage 2

### Option 2: [Second Alternative]
**Pros**:
- Advantage 1
- Advantage 2

**Cons**:
- Disadvantage 1
- Disadvantage 2

### Selected Option: [Chosen Option]
**Why we chose this**:
- Reason 1
- Reason 2
- Reason 3

**Trade-offs accepted**:
- Trade-off 1
- Trade-off 2

---

## Consequences

What becomes easier or more difficult because of this decision?

### Positive Consequences
- Benefit 1: [Explanation]
- Benefit 2: [Explanation]
- Benefit 3: [Explanation]

### Negative Consequences
- Cost 1: [Explanation and how we'll mitigate]
- Cost 2: [Explanation and how we'll mitigate]

### Neutral Consequences
- Impact 1: [Neither clearly positive nor negative]

---

## Implementation Notes

How will this decision be implemented? What are the key steps?

- Step 1: [Action item]
- Step 2: [Action item]
- Step 3: [Action item]

**Timeline**: [When will this be implemented?]  
**Dependencies**: [What needs to happen first?]  
**Migration Path**: [If changing from something existing, how?]

---

## Validation

How will we know if this was the right decision?

Success criteria:
- [ ] Criterion 1
- [ ] Criterion 2
- [ ] Criterion 3

**Review Date**: [When should we review this decision?]  
**Metrics to track**: [How will we measure success?]

---

## Related Decisions

- Supersedes: [ADR-XXX if applicable]
- Related to: [ADR-XXX if applicable]
- Influences: [ADR-XXX if applicable]

---

## References

- [Link to RFC or proposal]
- [Link to prototype or POC]
- [Link to documentation]
- [Link to discussion or meeting notes]

---

## Notes

Additional context, learnings, or future considerations.
