# Jobs-to-be-Done

This document outlines the key "jobs" that parents are hiring our product to do. Each JTBD represents a fundamental need, not a feature.

Format: **When I want to [circumstance/motivation], I can [capability], so that [outcome]**

---

## Core JTBDs - Custody Coordination

### JTBD-1: Know the custody schedule without asking

**When I want to** check who has custody on a specific date or time,  
**I can** open the app and see a clear, shared calendar,  
**so that** I don't have to text my ex and can plan my life confidently.

**User Stories**: US-1.1, US-1.2, US-1.3

**Current Alternatives**:
- Texting ex-spouse: "Do I have them this weekend?"
- Checking old text messages or emails
- Trying to remember the pattern
- Shared Google Calendar (but requires discipline)

**Pain Points Addressed**:
- Reduces uncomfortable communication
- Eliminates memory burden
- Provides single source of truth
- Accessible anytime

**Success Criteria**:
- Can find custody info in < 5 seconds
- Both parents see identical information
- Works offline for recently viewed schedules
- Mobile-optimized for on-the-go access

---

### JTBD-2: Request schedule changes without conflict

**When I want to** change a scheduled custody time (e.g., swap weekends),  
**I can** propose the change through a structured workflow,  
**so that** my ex can review and respond without text message arguments.

**User Stories**: US-2.1, US-2.2, US-2.3

**Current Alternatives**:
- Texting: "Can we swap weekends?" (often leads to long threads)
- Calling (may not be answered, leads to voicemails)
- Through kids (inappropriate but happens)
- Last-minute in-person requests

**Pain Points Addressed**:
- Reduces emotional back-and-forth
- Creates paper trail of requests
- Allows time for considered response
- Clarifies exactly what's being proposed

**Success Criteria**:
- Change request flow takes < 2 minutes
- Notifications prompt timely response
- Easy to see pending requests
- History of approved/denied changes

---

### JTBD-3: Document custody time accurately

**When I want to** prove who had custody when (for disputes or legal reasons),  
**I can** access an automatic log of all custody periods,  
**so that** I have evidence if disagreements arise.

**User Stories**: US-3.1, US-3.2

**Current Alternatives**:
- Trying to remember dates
- Searching through old texts
- Calendar screenshots
- Handwritten notes

**Pain Points Addressed**:
- Automatic record-keeping (no manual work)
- Timestamped and unmodifiable
- Accessible by both parties
- Exportable for legal use

**Success Criteria**:
- Custody log automatically generated
- Can export to PDF for attorneys
- Shows actual vs. scheduled custody
- Includes notes/deviations

---

### JTBD-4: Never miss a handoff

**When I want to** ensure I'm at the right place at the right time for custody handoffs,  
**I can** receive timely reminders and notifications,  
**so that** my kids aren't left waiting and we avoid conflict.

**User Stories**: US-4.1, US-4.2, US-4.3

**Current Alternatives**:
- Phone calendar reminders
- Setting multiple alarms
- Asking kids to remind them
- Relying on ex to text reminder

**Pain Points Addressed**:
- Reduces anxiety about forgetting
- Accounts for travel time
- Handles timezone differences
- Sends reminders to both parties

**Success Criteria**:
- Notifications arrive with enough lead time
- Include handoff location and time
- Option for "I'm on my way" status
- Confirm successful handoff

---

## Secondary JTBDs - Communication

### JTBD-5: Communicate without escalation

**When I want to** share information with my co-parent about our kids,  
**I can** send messages within the app with a clear purpose,  
**so that** we can stay focused on our children without personal conflict.

**User Stories**: US-5.1, US-5.2

**Current Alternatives**:
- Text messages (can escalate quickly)
- Email (too formal, gets buried)
- Phone calls (often avoided)
- Through kids (harmful)

**Pain Points Addressed**:
- Built-in safeguards against escalation
- Message history is searchable
- Can't be deleted later
- Context kept separate from personal texts

**Success Criteria**:
- Messages thread by topic
- Optional "cooling off" before sending
- Suggested templates for common messages
- Read receipts

---

### JTBD-6: Store shared information centrally

**When I want to** access important documents or information about our kids,  
**I can** find them in one shared location,  
**so that** we both have the latest court orders, medical info, or school documents.

**User Stories**: US-6.1, US-6.2, US-6.3

**Current Alternatives**:
- Emailing PDFs back and forth
- Shared Google Drive (requires setup)
- Physical folder at handoffs
- Asking ex to resend documents

**Pain Points Addressed**:
- Single location for all documents
- Version control (latest is clear)
- Organized by category
- Accessible to both parents

**Success Criteria**:
- Can upload from mobile device
- Search by filename or content
- Organized categories (Medical, Legal, School, etc.)
- Both parents can add documents

---

## Future JTBDs - Financial Coordination

### JTBD-7: Track shared expenses transparently

**When I want to** know what child-related expenses have been incurred,  
**I can** see a shared expense log with receipts,  
**so that** we can split costs fairly without arguments over money.

**User Stories**: US-7.1, US-7.2, US-7.3

**Current Alternatives**:
- Saving receipts, taking photos
- Spreadsheets emailed back and forth
- Venmo requests with descriptions
- Memory/"you owe me" conversations

**Pain Points Addressed**:
- Transparent record of expenses
- Attached proof (receipt photos)
- Automatic splitting calculations
- Request reimbursement in-app

**Success Criteria**:
- Can photograph receipt and upload
- Auto-categorize common expenses
- Track reimbursement status
- Export for tax purposes

---

### JTBD-8: Request expense reimbursement without awkwardness

**When I want to** get reimbursed for an expense I covered,  
**I can** submit a reimbursement request with proof,  
**so that** money matters stay businesslike and documented.

**User Stories**: US-8.1, US-8.2

**Current Alternatives**:
- "Hey, you owe me $X for..."
- Venmo requests (can be ignored)
- Keeping running tab (leads to disputes)
- Letting it go to avoid conflict

**Pain Points Addressed**:
- Formal process reduces awkwardness
- Receipt proof prevents disputes
- Status tracking (pending/paid)
- History for tax/legal purposes

**Success Criteria**:
- Submit request in < 1 minute
- Include receipt photo
- Set due date for payment
- Track payment method

---

## Future JTBDs - Child Information

### JTBD-9: Keep both parents informed about kids' lives

**When I want to** know what's happening with my kids' school, activities, or health,  
**I can** access a shared information hub,  
**so that** I'm not "out of the loop" when I don't have custody.

**User Stories**: US-9.1, US-9.2, US-9.3

**Current Alternatives**:
- Asking kids "what happened at school?"
- Asking ex (feels intrusive)
- Missing events/milestones
- Calling school directly (may not share with non-custodial)

**Pain Points Addressed**:
- Equal access to child information
- Stay connected during off-custody time
- Coordinate activities and appointments
- Reduce child's burden of updating both

**Success Criteria**:
- School calendar integration
- Activity schedules (sports, music, etc.)
- Health information (appointments, meds)
- Photo sharing of milestones

---

## How to Use This Document

### For Product Development
- Each JTBD should map to specific features
- When evaluating features, ask: "Which job does this help with?"
- JTBDs evolve - revisit quarterly

### For Prioritization
- Core JTBDs (1-4) are MVP
- Secondary JTBDs (5-6) are Phase 2
- Future JTBDs (7-9) are Phase 3+

### For User Research
- Interview parents using this language
- Validate that these jobs resonate
- Discover new jobs we haven't identified

### For Metrics
- Each JTBD should have success metrics
- Track how well we're fulfilling each job
- Survey users: "How well does the app help you [JTBD]?"

---

## Research Questions

- [ ] Are there JTBDs we're missing?
- [ ] How do these jobs vary by family situation (high-conflict vs. cooperative)?
- [ ] What jobs do step-parents or extended family need to do?
- [ ] How do children's ages affect these jobs?
- [ ] Are there cultural differences in how these jobs manifest?

---

## Mapping JTBDs to User Stories

See [user-stories.md](./user-stories.md) for detailed user stories that implement these JTBDs.

---

Last Updated: [DATE]
