# User Stories

User stories organized by Jobs-to-be-Done. Format: "When I want to <x>, I can <Y>, [optional] so that <Z>"

Status indicators:
- 🎯 **MVP** - Must have for initial release
- 🚀 **Phase 2** - Important but not MVP
- 💡 **Future** - Nice to have, lower priority
- ✅ **Done** - Implemented and tested
- 🚧 **In Progress** - Currently being worked on
- 📋 **Backlog** - Not started yet

---

## JTBD-1: Know the custody schedule without asking

### US-1.1: View custody calendar (🎯 MVP)
**When I want to** see who has custody this week,  
**I can** open the app and view a calendar showing custody periods,  
**so that** I can plan my week without asking my co-parent.

**Acceptance Criteria**:
- [ ] Calendar shows current week by default
- [ ] Clearly indicates which parent has custody each day
- [ ] Visual distinction between custody periods (color coding)
- [ ] Shows handoff times when custody changes
- [ ] Works on mobile (responsive design)
- [ ] Loads in < 2 seconds on 4G

**Technical Notes**:
- Use shadcn/ui calendar component
- Server-side render for performance
- Cache last 30 days + next 90 days
- Consider timezone of user

**Related Files**:
- `/src/components/schedule/CalendarView.tsx`
- `/src/lib/schedule/custody-periods.ts`

**Test Scenarios**:
- View calendar with no schedule (empty state)
- View calendar with basic weekly pattern
- View calendar with complex bi-weekly pattern
- View on mobile vs. desktop

---

### US-1.2: See schedule details (🎯 MVP)
**When I want to** see specific details about a custody period,  
**I can** tap/click on a calendar date and see handoff location, time, and notes,  
**so that** I know exactly when and where handoffs occur.

**Acceptance Criteria**:
- [ ] Clicking a date opens detail modal/panel
- [ ] Shows: Start time, end time, location, parent with custody
- [ ] Shows any special notes or instructions
- [ ] Option to add to personal calendar
- [ ] Works with keyboard navigation (accessibility)

**Technical Notes**:
- Modal component with smooth animation
- Deep link support for sharing specific dates
- Format times in user's timezone

**Related Files**:
- `/src/components/schedule/ScheduleDetailModal.tsx`

---

### US-1.3: Navigate to future/past dates (🎯 MVP)
**When I want to** check custody schedule for next month or look back at past periods,  
**I can** navigate forward and backward through the calendar,  
**so that** I can plan ahead or reference history.

**Acceptance Criteria**:
- [ ] Next/Previous month navigation buttons
- [ ] Date picker for jumping to specific date
- [ ] Shows at least 6 months future, 3 months past
- [ ] Infinite scroll on mobile (progressive loading)
- [ ] Clear visual indicator of "today"

**Technical Notes**:
- Lazy load future/past data as needed
- Prefetch next/previous month on hover
- Consider pagination vs. infinite scroll

---

### US-1.4: See schedule at a glance (🚀 Phase 2)
**When I want to** quickly check upcoming handoffs,  
**I can** see a summary view on the home screen,  
**so that** I don't need to navigate to full calendar.

**Acceptance Criteria**:
- [ ] Home screen widget showing next 3 handoffs
- [ ] Countdown timer to next handoff
- [ ] Quick action: "View full schedule"
- [ ] Updates in real-time

---

## JTBD-2: Request schedule changes without conflict

### US-2.1: Propose schedule change (🎯 MVP)
**When I want to** request swapping a weekend or changing a handoff time,  
**I can** create a change request with the proposed new schedule,  
**so that** my co-parent can review it formally rather than via text.

**Acceptance Criteria**:
- [ ] "Request Change" button on schedule view
- [ ] Form to select: original date/time, proposed date/time, reason
- [ ] Option to attach message/explanation
- [ ] Confirmation screen before sending
- [ ] Notification sent to other parent immediately
- [ ] Change request shows as "pending" on calendar

**Technical Notes**:
- Store as separate entity: ScheduleChangeRequest
- Include: requestor, requestee, original schedule, proposed schedule, status, created date
- Send notification via preferred channel (push/email/SMS)

**Related Files**:
- `/src/components/schedule/ChangeRequestForm.tsx`
- `/src/lib/schedule/change-requests.ts`

**User Flow**:
1. User clicks on scheduled custody period
2. Selects "Request Change"
3. Fills out form with proposed change
4. Reviews summary
5. Confirms & sends
6. Sees "Pending" status on calendar

---

### US-2.2: Respond to schedule change (🎯 MVP)
**When I want to** respond to a change request from my co-parent,  
**I can** approve, deny, or propose an alternative,  
**so that** we can formalize the change without multiple text exchanges.

**Acceptance Criteria**:
- [ ] Notification of new change request
- [ ] View request details: original vs proposed
- [ ] Three actions: Approve, Deny, Counter-propose
- [ ] Required field: Response message if denying
- [ ] Approval updates schedule immediately
- [ ] Both parties notified of response

**Technical Notes**:
- Request status workflow: Pending → Approved/Denied/Countered
- If approved, create ScheduleModification record
- Update calendar view in real-time (optimistic update)

**Test Scenarios**:
- Approve change request
- Deny with message
- Counter-propose different time
- Request expires (auto-deny after X days?)

---

### US-2.3: Track change request history (🚀 Phase 2)
**When I want to** see past schedule change requests,  
**I can** view a history of all requests (approved, denied, pending),  
**so that** I can reference past agreements.

**Acceptance Criteria**:
- [ ] "Change History" section
- [ ] Filter by: All, Approved, Denied, Pending
- [ ] Shows: Date, requestor, request details, response, status
- [ ] Exportable to PDF

---

### US-2.4: Set change request rules (💡 Future)
**When I want to** establish guidelines for change requests,  
**I can** set rules like "must request 48 hours in advance",  
**so that** expectations are clear upfront.

**Acceptance Criteria**:
- [ ] Settings page for change request rules
- [ ] Configurable: minimum notice period, auto-approve criteria
- [ ] Both parents must agree to rules
- [ ] App enforces rules (warns if violated)

---

## JTBD-3: Document custody time accurately

### US-3.1: View custody log (🎯 MVP)
**When I want to** see an accurate record of custody time,  
**I can** access an automatically-generated log showing who had custody when,  
**so that** I have documentation if needed.

**Acceptance Criteria**:
- [ ] "Custody Log" view accessible from menu
- [ ] Shows all custody periods with: dates, times, parent, duration
- [ ] Calculated metrics: total days per parent, percentage split
- [ ] Filter by date range
- [ ] Exportable to PDF/CSV

**Technical Notes**:
- Calculate from Schedule + ScheduleModification records
- Consider timezone in calculations
- Cache calculations for performance

**Related Files**:
- `/src/components/reports/CustodyLog.tsx`
- `/src/lib/reports/custody-calculations.ts`

---

### US-3.2: Export custody records (🎯 MVP)
**When I want to** provide custody records to my attorney or for court,  
**I can** export a PDF report of custody history,  
**so that** I have professional documentation.

**Acceptance Criteria**:
- [ ] "Export" button on custody log
- [ ] PDF includes: date range, custody breakdown, chart/graph
- [ ] Includes disclaimer: "This is a user-generated record"
- [ ] PDF is print-friendly
- [ ] Watermark with timestamp of generation

**Technical Notes**:
- Use jsPDF or similar for client-side generation
- Include QR code linking to verification page?
- Consider server-side PDF generation for better quality

---

### US-3.3: Note custody deviations (🚀 Phase 2)
**When I want to** document when actual custody differed from schedule,  
**I can** add a note to a custody period explaining the deviation,  
**so that** the log accurately reflects what happened.

**Acceptance Criteria**:
- [ ] "Add Note" option on any custody period
- [ ] Text field for explanation
- [ ] Both parents can see notes
- [ ] Notes appear in exported reports
- [ ] Timestamped and attributed to author

---

## JTBD-4: Never miss a handoff

### US-4.1: Receive handoff reminders (🎯 MVP)
**When I want to** ensure I'm on time for custody handoffs,  
**I can** receive notifications before each handoff,  
**so that** I'm never late and my children aren't left waiting.

**Acceptance Criteria**:
- [ ] Notification 24 hours before handoff
- [ ] Notification 2 hours before handoff
- [ ] Notification 30 minutes before handoff
- [ ] Customizable notification timing in settings
- [ ] Multiple channels: push, email, SMS (based on preference)
- [ ] Includes: time, location, which child(ren)

**Technical Notes**:
- Use AWS EventBridge for scheduled notifications
- Store notification preferences per user
- Handle timezone differences correctly
- Respect "Do Not Disturb" hours

**Related Files**:
- `/src/lib/notifications/handoff-reminders.ts`
- Lambda function: `/functions/send-notifications.ts`

---

### US-4.2: Confirm handoff completed (🚀 Phase 2)
**When I want to** confirm that a handoff happened successfully,  
**I can** mark it as complete in the app,  
**so that** both parents have confirmation.

**Acceptance Criteria**:
- [ ] "Confirm Handoff" button appears 1 hour before handoff time
- [ ] One tap to confirm
- [ ] Shows confirmation status to both parents
- [ ] Timestamp of confirmation
- [ ] Optional: Add note or photo

**Technical Notes**:
- Add `confirmed_at` and `confirmed_by` fields to custody periods
- Send notification to other parent when confirmed
- Consider geofencing to auto-confirm (privacy concerns?)

---

### US-4.3: Handle missed/late handoffs (💡 Future)
**When I want to** communicate that I'm running late or can't make a handoff,  
**I can** send an alert with estimated arrival or propose quick reschedule,  
**so that** the other parent is informed immediately.

**Acceptance Criteria**:
- [ ] "I'm Running Late" quick action
- [ ] Select estimated delay (15, 30, 45+ mins)
- [ ] Optional message to co-parent
- [ ] Shows updated ETA to other parent
- [ ] Log of late handoffs for patterns

---

## JTBD-5: Communicate without escalation (🚀 Phase 2)

### US-5.1: Send focused messages
**When I want to** communicate with my co-parent about our children,  
**I can** send messages categorized by topic,  
**so that** conversations stay organized and purposeful.

**Acceptance Criteria**:
- [ ] Message composer with category selection
- [ ] Categories: Schedule, Medical, School, Activities, Other
- [ ] Messages thread by category
- [ ] Can attach photos/documents
- [ ] Read receipts (optional)
- [ ] Persistent, searchable history

---

### US-5.2: Use message templates
**When I want to** send common messages quickly,  
**I can** use pre-written templates,  
**so that** I can communicate efficiently without composing from scratch.

**Acceptance Criteria**:
- [ ] Template library (e.g., "I'm running 15 minutes late")
- [ ] Customizable templates
- [ ] Quick actions for common scenarios
- [ ] Fill-in-the-blank templates

---

## JTBD-6: Store shared information centrally (🚀 Phase 2)

### US-6.1: Upload documents
**When I want to** share important documents with my co-parent,  
**I can** upload files organized by category,  
**so that** we both have access to the latest versions.

**Acceptance Criteria**:
- [ ] Upload button with drag-and-drop
- [ ] Categories: Legal, Medical, School, Other
- [ ] Support: PDF, images, Word docs
- [ ] File size limit: 10MB per file
- [ ] Virus scanning on upload
- [ ] Thumbnail previews for images

---

### US-6.2: Search documents
**When I want to** find a specific document,  
**I can** search by filename, category, or date,  
**so that** I can quickly locate what I need.

**Acceptance Criteria**:
- [ ] Search bar in document library
- [ ] Search by: filename, category, upload date, uploader
- [ ] Results ranked by relevance
- [ ] Filter results by category

---

### US-6.3: Version control for documents
**When I want to** upload a newer version of a document,  
**I can** replace the old version while keeping history,  
**so that** we always reference the latest but can see what changed.

**Acceptance Criteria**:
- [ ] "Upload new version" option on documents
- [ ] Version history shows all versions with dates
- [ ] Can download previous versions
- [ ] Clear indication of "current" version

---

## JTBD-7: Track shared expenses transparently (💡 Future)

### US-7.1: Log expenses
**When I want to** record a child-related expense,  
**I can** add it with receipt photo and details,  
**so that** we have a shared record.

**Acceptance Criteria**:
- [ ] "Add Expense" form
- [ ] Fields: amount, category, description, receipt photo
- [ ] Auto-categorize common expenses (medical, school, etc.)
- [ ] Split percentage (50/50 default, customizable)
- [ ] Both parents see all expenses

---

### US-7.2: Request reimbursement
**When I want to** get reimbursed for an expense I paid,  
**I can** submit a reimbursement request,  
**so that** money matters are handled formally.

**Acceptance Criteria**:
- [ ] "Request Reimbursement" from expense entry
- [ ] Shows calculation: amount × split percentage
- [ ] Set due date for payment
- [ ] Track status: Pending, Paid, Disputed
- [ ] Notification to other parent

---

### US-7.3: Export expenses for taxes
**When I want to** prepare taxes,  
**I can** export expenses by category and year,  
**so that** I have records for deductions.

**Acceptance Criteria**:
- [ ] Export to CSV or PDF
- [ ] Filter by: year, category, payer
- [ ] Summary totals
- [ ] Include receipt images in PDF

---

## JTBD-9: Keep both parents informed about kids' lives (💡 Future)

### US-9.1: Share child information
**When I want to** update information about our children,  
**I can** add details to child profiles,  
**so that** both parents have current info.

**Acceptance Criteria**:
- [ ] Child profile with: medical info, school, activities
- [ ] Both parents can edit
- [ ] Change history/audit log
- [ ] Emergency contact info
- [ ] Allergies and medications

---

### US-9.2: Sync school calendars
**When I want to** know school events and holidays,  
**I can** import the school calendar,  
**so that** both parents are aware of important dates.

**Acceptance Criteria**:
- [ ] Import .ics calendar files
- [ ] School events appear on custody calendar
- [ ] Color-coded differently from custody periods
- [ ] Can add notes to events

---

### US-9.3: Track activities and appointments
**When I want to** coordinate children's activities,  
**I can** add activities to a shared schedule,  
**so that** both parents know about practices, games, appointments.

**Acceptance Criteria**:
- [ ] Add recurring activities (soccer practice every Tuesday)
- [ ] Note which parent is responsible for transportation
- [ ] Reminders before activities
- [ ] Link to custody schedule (show who has custody)

---

## Story Mapping & Prioritization

### MVP (Phase 1) - Must Have
Focus: Core custody coordination
- All JTBD-1 stories (calendar viewing)
- All JTBD-2 stories (change requests)
- All JTBD-3 stories (custody log)
- All JTBD-4 stories (reminders)

Estimated: **8-12 weeks development**

### Phase 2 - Communication & Documents
- JTBD-5 stories (messaging)
- JTBD-6 stories (document storage)
- Enhanced handoff features

Estimated: **6-8 weeks development**

### Phase 3 - Financial & Child Info
- JTBD-7 stories (expenses)
- JTBD-9 stories (child information)
- Advanced reporting

Estimated: **8-10 weeks development**

---

## Story Template (Copy for New Stories)

```markdown
### US-X.X: [Story Title] ([Status])
**When I want to** [circumstance/goal],  
**I can** [action/capability],  
**so that** [outcome/benefit].

**Acceptance Criteria**:
- [ ] Criterion 1
- [ ] Criterion 2
- [ ] Criterion 3

**Technical Notes**:
- Implementation considerations
- Related patterns or libraries
- Performance considerations

**Related Files**:
- `/path/to/relevant/file.ts`

**Test Scenarios**:
- Scenario 1
- Scenario 2
```

---

## Notes on Usage

### For Development
- Link GitHub issues to specific user stories (e.g., "Implements US-1.1")
- Break large stories into smaller tasks
- User stories are the "what", technical tasks are the "how"

### For Testing
- Acceptance criteria become test cases
- Each story should have happy path + edge case tests
- Consider accessibility testing for all UI stories

### For Product Decisions
- If a feature doesn't map to a user story, question if we need it
- Stories should be independently valuable
- Prioritize stories that complete a job end-to-end

---

Last Updated: [DATE]
