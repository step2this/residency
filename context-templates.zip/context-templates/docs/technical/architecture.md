# System Architecture

High-level architecture for the co-parenting custody scheduling application.

**Last Updated**: [DATE]

---

## Architecture Diagram

```
┌─────────────────────────────────────────────────────────────┐
│                         User Devices                         │
│  (Mobile Browsers, Desktop Browsers, Future: Native Apps)   │
└─────────────────────────┬───────────────────────────────────┘
                          │ HTTPS
                          ▼
┌─────────────────────────────────────────────────────────────┐
│                      CDN (CloudFront)                        │
│          (Static Assets, Images, Edge Caching)               │
└─────────────────────────┬───────────────────────────────────┘
                          │
                          ▼
┌─────────────────────────────────────────────────────────────┐
│                    Frontend (Next.js)                        │
│   - Server-Side Rendering (SSR)                             │
│   - React Server Components                                  │
│   - API Routes (for prototyping)                            │
│   - Deployed on Vercel or AWS Amplify                       │
└───────────┬─────────────────────────────┬───────────────────┘
            │                             │
            │ REST/GraphQL                │ WebSocket (future)
            ▼                             ▼
┌─────────────────────────┐    ┌─────────────────────────────┐
│   API Gateway (AWS)     │    │  Real-time (future)         │
│   - Authentication      │    │  - WebSocket API            │
│   - Rate Limiting       │    │  - Push Notifications       │
│   - Request Routing     │    └─────────────────────────────┘
└──────────┬──────────────┘
           │
           ▼
┌─────────────────────────────────────────────────────────────┐
│              Backend Services (AWS Lambda)                   │
├─────────────────────────────────────────────────────────────┤
│  ┌────────────────┐  ┌────────────────┐  ┌───────────────┐ │
│  │  Schedule      │  │  Change        │  │  Notification │ │
│  │  Management    │  │  Requests      │  │  Service      │ │
│  └────────────────┘  └────────────────┘  └───────────────┘ │
│                                                              │
│  ┌────────────────┐  ┌────────────────┐  ┌───────────────┐ │
│  │  User          │  │  Document      │  │  Reports      │ │
│  │  Management    │  │  Storage       │  │  Generator    │ │
│  └────────────────┘  └────────────────┘  └───────────────┘ │
└───────────┬──────────────────────────────────────────┬──────┘
            │                                          │
            ▼                                          ▼
┌─────────────────────────┐              ┌─────────────────────┐
│   DynamoDB              │              │  S3 Buckets         │
│   - Users table         │              │  - Documents        │
│   - Schedules table     │              │  - Receipts         │
│   - ChangeRequests      │              │  - Generated PDFs   │
│   - Notifications       │              └─────────────────────┘
└─────────────────────────┘
            │
            ▼
┌─────────────────────────┐
│   EventBridge           │
│   - Scheduled reminders │
│   - Event-driven tasks  │
└─────────────────────────┘
```

---

## Component Overview

### Frontend Layer

**Technology**: Next.js 15 (App Router), React 19, TypeScript, Tailwind CSS

**Responsibilities**:
- Render UI (Server Components where possible)
- Handle user interactions
- Client-side routing
- Form validation
- Optimistic UI updates
- Authentication state management

**Key Directories**:
- `/app` - Routes and pages (App Router)
- `/components` - Reusable React components
- `/lib` - Business logic, utilities, API clients
- `/hooks` - Custom React hooks

**Deployment**: Vercel (primary) or AWS Amplify (alternative)

---

### API Gateway Layer

**Technology**: AWS API Gateway (REST or HTTP API)

**Responsibilities**:
- Route requests to Lambda functions
- Authentication/authorization (JWT validation)
- Rate limiting and throttling
- CORS handling
- Request/response transformation
- API versioning

**Configuration**:
- Base URL: `https://api.yourdomain.com`
- API versions: `/v1/`, `/v2/` etc.
- Authentication: JWT tokens in Authorization header

---

### Backend Services Layer

**Technology**: AWS Lambda (Node.js 20.x), TypeScript

**Architecture Pattern**: Event-driven microservices

#### Service: Schedule Management
**Purpose**: Handle custody schedule CRUD operations

**Functions**:
- `getSchedule` - Retrieve schedule by ID
- `listSchedules` - List schedules for a parent
- `createSchedule` - Create new custody schedule
- `updateSchedule` - Modify existing schedule
- `deleteSchedule` - Soft delete schedule
- `calculateCustodyPeriods` - Calculate custody time ranges

**Data Access**: DynamoDB (Schedules table)

---

#### Service: Change Request Management
**Purpose**: Handle schedule change request workflow

**Functions**:
- `createChangeRequest` - Submit new change request
- `respondToChangeRequest` - Approve/deny/counter
- `listChangeRequests` - Get pending/historical requests
- `applyApprovedChange` - Update schedule when approved

**Data Access**: DynamoDB (ChangeRequests table)

**Events Published**:
- `ChangeRequestCreated` - Triggers notification
- `ChangeRequestApproved` - Updates schedule
- `ChangeRequestDenied` - Notifies requestor

---

#### Service: Notification Service
**Purpose**: Send notifications via email, SMS, push

**Functions**:
- `sendHandoffReminder` - Send scheduled handoff reminders
- `sendChangeRequestNotification` - Alert about new requests
- `sendChangeResponseNotification` - Alert about responses
- `sendCustomNotification` - General purpose notifications

**Integrations**:
- AWS SES (email)
- AWS SNS (SMS)
- Firebase Cloud Messaging or OneSignal (push - future)

**Triggers**:
- EventBridge scheduled rules (for reminders)
- Direct Lambda invocations from other services
- Event-driven from DynamoDB streams

---

#### Service: User Management
**Purpose**: Handle user profiles, preferences, authentication

**Functions**:
- `getUser` - Get user profile
- `updateUser` - Update user profile
- `getUserPreferences` - Get notification/app preferences
- `updatePreferences` - Update preferences
- `linkCoParents` - Establish co-parent relationship

**Authentication**: 
- Option 1: AWS Cognito user pools
- Option 2: Clerk or Auth0 (if easier integration)
- Option 3: Auth.js (Next-Auth)

**Data Access**: DynamoDB (Users table)

---

#### Service: Document Storage
**Purpose**: Store and retrieve shared documents

**Functions**:
- `uploadDocument` - Upload to S3, create metadata
- `getDocument` - Generate presigned URL for download
- `listDocuments` - List documents by category
- `deleteDocument` - Soft delete document
- `updateDocumentMetadata` - Update name, category, etc.

**Storage**: S3 bucket with versioning enabled

**Security**:
- Virus scanning on upload (AWS Lambda + ClamAV)
- Presigned URLs with expiration (15 min)
- Per-user directory structure in S3

---

#### Service: Reports Generator
**Purpose**: Generate custody logs, expense reports, etc.

**Functions**:
- `generateCustodyLog` - PDF of custody history
- `generateExpenseReport` - PDF of expenses (future)
- `exportSchedule` - iCal format export

**Technology**: 
- jsPDF or Puppeteer for PDF generation
- Run in Lambda with increased memory/timeout

---

### Data Layer

**Technology**: Amazon DynamoDB (NoSQL)

**Why DynamoDB**:
- Serverless, scales automatically
- Single-digit millisecond latency
- Works well with Lambda
- Pay per request (cost-effective for MVP)
- Strong consistency option available

#### Table Design

**Users Table**
```
PK: USER#{userId}
SK: PROFILE

Attributes:
- userId (string)
- email (string)
- firstName (string)
- lastName (string)
- timezone (string)
- createdAt (timestamp)
- notificationPreferences (map)

GSI-1:
PK: EMAIL#{email}
SK: USER
```

**Schedules Table**
```
PK: PARENT#{parentId}
SK: SCHEDULE#{scheduleId}

Attributes:
- scheduleId (string)
- parentIds (list of strings) [both parents]
- childId (string)
- recurrence (string) - rrule format
- startDate (ISO timestamp)
- endDate (ISO timestamp, nullable)
- handoffLocation (string)
- notes (string)
- status (active/archived)
- createdAt (timestamp)
- updatedAt (timestamp)

GSI-1 (for querying by schedule ID):
PK: SCHEDULE#{scheduleId}
SK: METADATA
```

**ChangeRequests Table**
```
PK: SCHEDULE#{scheduleId}
SK: REQUEST#{timestamp}

Attributes:
- requestId (string)
- scheduleId (string)
- requestorId (string)
- requesteeId (string)
- originalStartTime (timestamp)
- originalEndTime (timestamp)
- proposedStartTime (timestamp)
- proposedEndTime (timestamp)
- reason (string)
- status (pending/approved/denied/countered)
- response (string, nullable)
- createdAt (timestamp)
- respondedAt (timestamp, nullable)

GSI-1 (pending requests for a user):
PK: USER#{userId}
SK: STATUS#{status}#CREATED#{createdAt}
```

**Notifications Table**
```
PK: USER#{userId}
SK: NOTIFICATION#{timestamp}

Attributes:
- notificationId (string)
- userId (string)
- type (handoff_reminder/change_request/etc)
- title (string)
- message (string)
- read (boolean)
- createdAt (timestamp)
- scheduledFor (timestamp, for future delivery)

GSI-1 (unread notifications):
PK: USER#{userId}
SK: READ#{false}#CREATED#{createdAt}
```

---

### Storage Layer

**Technology**: Amazon S3

**Buckets**:

1. **Documents Bucket** (`app-documents-{env}`)
   - Structure: `/{userId}/{category}/{timestamp}-{filename}`
   - Versioning: Enabled
   - Lifecycle: Archive to Glacier after 1 year
   - Encryption: AES-256 (server-side)

2. **Generated Reports Bucket** (`app-reports-{env}`)
   - Structure: `/{userId}/reports/{reportId}.pdf`
   - Lifecycle: Delete after 7 days (temporary downloads)

3. **Static Assets Bucket** (`app-static-{env}`)
   - Structure: `/images/*`, `/fonts/*`, etc.
   - CloudFront distribution for CDN
   - Public read access

---

### Event-Driven Architecture

**Technology**: Amazon EventBridge

**Event Patterns**:

```javascript
// Handoff Reminder Schedule
{
  source: "custody-app.schedules",
  detail-type: "HandoffReminder",
  detail: {
    scheduleId: "schedule-123",
    parentId: "user-456",
    handoffTime: "2025-01-15T18:00:00Z"
  }
}

// Change Request Created
{
  source: "custody-app.change-requests",
  detail-type: "ChangeRequestCreated",
  detail: {
    requestId: "req-789",
    requestorId: "user-456",
    requesteeId: "user-789"
  }
}
```

**Scheduled Rules**:
- Check for handoffs in next 24 hours (runs every hour)
- Check for handoffs in next 2 hours (runs every 15 min)
- Check for handoffs in next 30 minutes (runs every 5 min)

---

## Cross-Cutting Concerns

### Authentication & Authorization

**Authentication**: JWT tokens issued by auth provider

**Token Flow**:
1. User logs in via frontend
2. Auth provider (Cognito/Clerk/Auth.js) issues JWT
3. Frontend includes JWT in Authorization header
4. API Gateway validates JWT
5. Lambda extracts user ID from token claims

**Authorization**:
- User can only access their own data
- Both parents can access shared schedules
- Implement fine-grained permissions (e.g., can't delete other parent's notes)

**Implementation**:
```typescript
// Lambda authorizer or inline checks
const userId = event.requestContext.authorizer.claims.sub
const schedule = await getSchedule(scheduleId)
if (!schedule.parentIds.includes(userId)) {
  throw new ForbiddenError()
}
```

---

### Error Handling

**Standards**:
- Return appropriate HTTP status codes
- Include error code for client handling
- Log errors with context for debugging
- Don't expose internal details to client

**Error Response Format**:
```json
{
  "error": {
    "code": "SCHEDULE_NOT_FOUND",
    "message": "The requested schedule does not exist",
    "details": {
      "scheduleId": "schedule-123"
    }
  }
}
```

**Logging**: CloudWatch Logs with structured JSON

---

### Security

**API Security**:
- HTTPS only (TLS 1.2+)
- JWT authentication required (except public pages)
- Rate limiting per user (100 req/min)
- Input validation using Zod schemas
- SQL injection not applicable (DynamoDB)
- XSS protection (React escapes by default)

**Data Security**:
- Encryption at rest (DynamoDB, S3)
- Encryption in transit (HTTPS)
- Presigned URLs expire in 15 minutes
- No sensitive data in logs
- User data isolated by partition key

**Compliance Considerations**:
- GDPR: Right to deletion, data portability
- COPPA: No direct data collection from children
- Family law: Data may be subpoenaed

---

### Performance

**Targets**:
- API response time: < 200ms (p95)
- Page load time: < 2s (p95) on 4G
- Time to Interactive: < 3s

**Optimization Strategies**:
- DynamoDB on-demand pricing for predictable performance
- CloudFront CDN for static assets
- Next.js Server Components reduce client JS
- API response caching (short TTL for dynamic data)
- Lambda provisioned concurrency for critical functions (if needed)

---

### Monitoring & Observability

**Metrics** (CloudWatch):
- Lambda execution time, errors, throttles
- API Gateway requests, latency, 4xx/5xx errors
- DynamoDB consumed capacity, throttled requests
- Application-specific: schedule creation rate, change request approval rate

**Alarms**:
- Lambda error rate > 5%
- API Gateway 5xx rate > 1%
- Lambda duration > 10s (adjust per function)

**Logging**:
- Structured JSON logs
- Include correlation ID in all logs
- Log level: INFO in production, DEBUG in dev

**Tracing** (X-Ray - optional):
- Enable for debugging complex issues
- Track request path through microservices

---

## Deployment Architecture

### Environments

1. **Development** (`dev`)
   - Developer local machines
   - Connects to dev AWS resources
   - Hot reload, minimal caching

2. **Staging** (`staging`)
   - Deployed on push to `develop` branch
   - Mirrors production setup
   - Used for QA and testing

3. **Production** (`prod`)
   - Deployed on push to `main` branch
   - Full monitoring and alarms
   - Blue-green or canary deployments

### Infrastructure as Code

**Tool**: AWS CDK or CloudFormation

**Resources Defined**:
- Lambda functions
- DynamoDB tables
- S3 buckets
- API Gateway
- EventBridge rules
- IAM roles and policies
- CloudWatch alarms

**Deployment**:
```bash
# Deploy infrastructure
cdk deploy --all --profile custody-app

# Deploy Next.js frontend
vercel deploy --prod
```

---

## Scaling Considerations

**Current Architecture** (MVP):
- Handles ~100 concurrent users
- ~1,000 requests/minute
- ~10,000 total users

**Scaling Path**:
- DynamoDB scales automatically (on-demand mode)
- Lambda scales automatically (up to account limits)
- CloudFront handles global CDN
- Add read replicas if switching to RDS later
- Consider AWS AppSync for GraphQL (future)

**Bottlenecks to Watch**:
- API Gateway throttling limits
- Lambda concurrent execution limits
- DynamoDB hot partitions (if access patterns are unbalanced)

---

## Technology Decisions

**Why This Architecture**:
- **Serverless**: Scales automatically, pay-per-use
- **Event-driven**: Decouples services, enables async processing
- **Next.js SSR**: Fast initial loads, SEO-friendly
- **DynamoDB**: Fast, scalable, low-ops overhead
- **Lambda**: Perfect for API workloads, no server management

**Trade-offs**:
- **Cold starts**: Lambda can have 1-2s cold start (mitigate with provisioned concurrency)
- **DynamoDB learning curve**: NoSQL requires different data modeling
- **Vendor lock-in**: Heavily AWS-specific (mitigate with abstraction layers)

---

## Future Architecture Evolution

**Phase 2: Real-time Features**
- Add WebSocket API for real-time updates
- Implement optimistic UI updates
- Real-time schedule change notifications

**Phase 3: Advanced Analytics**
- Data pipeline to S3 data lake
- Analytics with Athena or QuickSight
- ML for schedule optimization (stretch goal)

**Phase 4: Multi-region**
- CloudFront already global
- DynamoDB Global Tables for multi-region writes
- Lambda@Edge for region-specific logic

---

## References

- [AWS Well-Architected Framework](https://aws.amazon.com/architecture/well-architected/)
- [Next.js Documentation](https://nextjs.org/docs)
- [DynamoDB Best Practices](https://docs.aws.amazon.com/amazondynamodb/latest/developerguide/best-practices.html)

---

Last Updated: [DATE]
