# Current Focus

**Last Updated**: [DATE]  
**Sprint**: Sprint X ([START_DATE] - [END_DATE])  
**Sprint Goal**: [One sentence describing the main objective this sprint]

---

## This Week's Priorities

1. **[Priority 1]** - Issue #XX: [Brief description]
2. **[Priority 2]** - Issue #XX: [Brief description]
3. **[Priority 3]** - Issue #XX: [Brief description]

---

## Active Work in Progress

| Issue | Title | Status | Owner | Notes |
|-------|-------|--------|-------|-------|
| #XX | [Feature/Task name] | In Progress | [Name] | [Any relevant context] |
| #XX | [Feature/Task name] | Blocked | [Name] | [What's blocking it] |

---

## Product Context

**Related JTBDs**: JTBD-X, JTBD-Y (see `docs/requirements/jobs-to-be-done.md`)  
**Related User Stories**: US-X.X to US-Y.Y (see `docs/requirements/user-stories.md`)

**Key Product Decisions This Sprint**:
- [Decision 1 and rationale]
- [Decision 2 and rationale]

---

## Technical Context

**Architecture Decisions**: See `docs/adr/[RELEVANT_ADR].md`

**Current Tech Focus**:
- [e.g., Implementing calendar component using shadcn/ui]
- [e.g., DynamoDB schema changes for recurring schedules]
- [e.g., Timezone handling with date-fns-tz]

**Key Files Being Modified**:
- `/src/[path]/[filename]` - [Why this file is important right now]
- `/src/[path]/[filename]` - [Why this file is important right now]

---

## Blockers & Decisions Needed

- [ ] **[Blocker 1]**: [Description and what's needed to unblock]
- [ ] **[Decision needed]**: [What needs to be decided and by when]

---

## Recently Completed (Last 7 Days)

- ✅ Issue #XX: [What was completed]
- ✅ Issue #XX: [What was completed]
- ✅ Issue #XX: [What was completed]

---

## Next Session TODO

When starting your next Claude Code session, focus on:

1. [Specific next task]
2. [Specific next task]
3. [Specific next task]

**Files to Review First**: [List any files Claude should examine before starting]

---

## Quick Links

- [Product Vision](docs/requirements/product-vision.md)
- [Jobs-to-be-Done](docs/requirements/jobs-to-be-done.md)
- [User Stories](docs/requirements/user-stories.md)
- [Architecture Overview](docs/technical/architecture.md)
- [GitHub Project Board](https://github.com/[YOUR_ORG]/[YOUR_REPO]/projects/X)
